export type ContractType = "interest_only" | "installments";

export interface Client {
  id: number;
  name: string;
  contact: string;
  createdAt: string;
  deleted: boolean;
}

export interface Contract {
  id: number;
  clientId: number;
  capital: number;
  rate: number;
  type: ContractType;
  /** Intervalo entre parcelas: mensal (padrão) ou a cada 15 dias. */
  frequency?: "monthly" | "biweekly";
  installmentsCount: number | null;
  startDate: string;
  active: boolean;
  deleted: boolean;
  totalPaid: number;
  nextInstallmentNumber: number;
  /** Abatimentos de capital recebidos (contratos "somente juros"). */
  capitalAbatements?: CapitalAbatement[];
}

export interface CapitalAbatement {
  id: number;
  amount: number;
  cashEntryId: number;
  date: string;
}

export interface Installment {
  id: number;
  contractId: number;
  number: number;
  total: number;
  interest: number;
  amortization?: number;
  dueDate: string;
  /** Valor já recebido em pagamentos parciais desta parcela. */
  paidAmount?: number;
  paid: boolean;
  paidDate: string | null;
  deleted: boolean;
  generatedInstallmentId: number | null;
}

export interface CashEntry {
  id: number;
  type: "in" | "out";
  amount: number;
  description: string;
  date: string;
  createdAt: string;
}

export interface AppData {
  clients: Client[];
  contracts: Contract[];
  installments: Installment[];
  cashEntries: CashEntry[];
  trash: {
    clients: Client[];
    contracts: Contract[];
    installments: Installment[];
  };
  nextId: number;
}

export const getDefaultData = (): AppData => ({
  clients: [],
  contracts: [],
  installments: [],
  cashEntries: [],
  trash: { clients: [], contracts: [], installments: [] },
  nextId: 1,
});
